package com.jd.expection;

public class ApnaException extends Exception {

	public ApnaException() {
		super("super exception ala");
	}
	public void exception() {
		System.out.println("exception ala");
	}
}
