package com.jd.junit;

public class Maths {

	int divide(int a, int b) {
		return a/b;
	}
	
	int mul(int a, int b) {
		return a*b;
	}
}
