package com.jd.interviews;

import com.jd.interviews.Sprite.Direction;

class Sprite {

	public enum Direction {NORTH, SOUTH, EAST, WEST};
	
}

public class EnumTest {
	
	Direction d = Direction.NORTH;
}
