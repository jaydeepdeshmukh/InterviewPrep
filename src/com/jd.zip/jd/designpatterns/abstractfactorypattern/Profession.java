package com.jd.designpatterns.abstractfactorypattern;

public interface Profession {

	void print();
}
