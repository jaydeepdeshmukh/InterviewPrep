package com.jd.designpatterns.abstractfactorypattern;

abstract class AbstractFactory {

	abstract Profession getProfession(String profession);
}
