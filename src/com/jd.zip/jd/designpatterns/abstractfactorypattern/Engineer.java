package com.jd.designpatterns.abstractfactorypattern;

public class Engineer implements Profession {

	@Override
	public void print() {
		System.out.println("I am engineer");
	}

}
