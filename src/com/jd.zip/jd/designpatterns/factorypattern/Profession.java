package com.jd.designpatterns.factorypattern;

public interface Profession {

	void print();
}
