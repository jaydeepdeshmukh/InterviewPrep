package com.jd.designpatterns.factorypattern;

public class Teacher implements Profession {

	@Override
	public void print() {
		System.out.println("I am teacher");

	}

}
