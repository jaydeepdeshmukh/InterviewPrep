package com.jd.test;

public interface TestInterface {

	abstract void add();
}
